package GUI.renderers;

import javax.swing.JPanel;

import core.Main;

import parts.Element;

public abstract class Renderer extends JPanel {

	protected Element elm;
	protected Main parent;
	
	
	public Renderer(Element elm,Main parent) {
		super();
		this.elm = elm;
		this.parent=parent;
	}

	public Element getElement(){
		return elm;
	}

	public abstract void update();
	
}
