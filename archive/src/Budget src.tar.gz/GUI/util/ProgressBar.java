package GUI.util;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JComponent;

public class ProgressBar extends JComponent{
	
	private double max;
	private double min;
	private double value;
	
	private Area left;
	private Area right;
	
	private Color fore;
	private Color fore2;
	private Color back;
	private Color back2;
	
	private boolean reversed;

	public ProgressBar(double max, double min, double value, boolean reversed, Color fore, Color back) {
		super();
		this.max = max;
		this.min = min;
		this.reversed = reversed;
		if(reversed){
			this.value = (max-value);
		
			this.back=fore;
			this.back2=fore.darker();
			this.fore=back;
			this.fore2=back.brighter();
		}else{
			this.value = value;
			
			this.back=back;
			this.back2=back.brighter();
			this.fore=fore;
			this.fore2=fore.darker();
		}
			
		init();
		update();
	}

	public double getValue() {
		return value;
	}

	public void setValue(double value) {
		if(!reversed){
		this.value = value;
		}else{
			this.value=(max-value);
		}
		update();
	}
	
	private void init(){
		setPreferredSize(new Dimension(25,25));
		
		setLocale(null);
		
		left=new Area(fore,fore2,Area.Vertical);
		add(left);
		
		right=new Area(back,back2,Area.Vertical);
		add(right);
	}
	
	public void update(){
		int width=getWidth();
		int height=getHeight();

		double t=(value-min)/(max-min);
		
		left.setBounds(5, 5, (int)Math.round(width*t), height-5);
		right.setBounds((int)Math.round(width*t), 5,(int)Math.round(width*(1-t)) , height-5);
	}

	public double getMax() {
		return max;
	}

	public void setMax(double max) {
		this.max = max;
		update();
	}

	public double getMin() {
		return min;
	}

	public void setMin(double min) {
		this.min = min;
		update();
	}

	public boolean isReversed() {
		return reversed;
	}

	public void setReversed(boolean reversed) {
		this.reversed = reversed;
		update();
	}
	
	

}
