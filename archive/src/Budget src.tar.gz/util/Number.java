package util;

public class Number {

	
	/**
	 * Rounds the given number to two decimal places
	 * @param in The number to round off
	 * @return The rounded off number
	 */
	public static double round2Dp(double in){
		return round(in,2);
	}
	
	/**
	 * Rounds the given number to 'dp' decimal places
	 * @param in The number to round off
	 * @param dp The number of decimal places
	 * @return The rounded off number
	 */
	
	public static double round(double in, int dp){
		double i=Math.pow(10, dp);
		return Math.round(in*i)/i;
	}
}
