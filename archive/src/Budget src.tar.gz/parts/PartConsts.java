package parts;

public interface PartConsts {

	public static final int MONTHLY=1;
	public static final int WEEKLY=2;
	public static final int DAILY=3;
	
	public static final int EXPENCE=5;
	public static final int ALLOWANCE=6;
	public static final int SAVINGS=7;
	
}
