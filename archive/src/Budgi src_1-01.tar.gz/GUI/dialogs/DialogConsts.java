package GUI.dialogs;

public interface DialogConsts {

	public static final int CANCEL = 1;
	public static final int OK = 2;

}
