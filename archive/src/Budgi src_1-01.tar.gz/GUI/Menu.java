package GUI;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import GUI.handlers.MenuEventHandler;

public class Menu extends JMenu implements ActionListener {

	private JMenuItem add;
	private JMenuItem remove;
	private JMenuItem total;
	private JMenuItem refresh;
	private JMenuItem options;
	private JMenuItem save;
	private JMenuItem saveOld;
	private JMenuItem close;
	private JMenuItem reload;

	private MenuEventHandler handler;

	public Menu(MenuEventHandler handler) {
		super("File");

		this.handler = handler;

		add = new JMenuItem("Add Account");
		add.addActionListener(this);
		add.setActionCommand("M.add");
		add(add);

		remove = new JMenuItem("Remove Account");
		remove.addActionListener(this);
		remove.setActionCommand("M.remove");
		add(remove);

		total = new JMenuItem("Show total in accounts");
		total.addActionListener(this);
		total.setActionCommand("M.total");
		add(total);

		refresh = new JMenuItem("Refresh");
		refresh.addActionListener(this);
		refresh.setActionCommand("M.refresh");
		add(refresh);

		options = new JMenuItem("Options");
		options.addActionListener(this);
		options.setActionCommand("M.options");
		add(options);

		save = new JMenuItem("Save");
		save.addActionListener(this);
		save.setActionCommand("M.save");
		add(save);

		reload = new JMenuItem("Reload");
		reload.addActionListener(this);
		reload.setActionCommand("M.reload");
		add(reload);

		saveOld = new JMenuItem("Archive");
		saveOld.addActionListener(this);
		saveOld.setActionCommand("M.saveOld");
		add(saveOld);

		addSeparator();

		close = new JMenuItem("Close");
		close.addActionListener(this);
		close.setActionCommand("M.close");
		add(close);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		String command = arg0.getActionCommand();
		if (!command.startsWith("M."))
			return;

		if (command.equals("M.add")) {
			handler.addElement();
		} else if (command.equals("M.remove")) {
			handler.remove();
		} else if (command.equals("M.total")) {
			handler.showCurrentBalance();
		} else if (command.equals("M.refresh")) {
			handler.refresh();
		} else if (command.equals("M.options")) {
			handler.options();
		} else if (command.equals("M.save")) {
			handler.save();
		} else if (command.equals("M.reload")) {
			handler.reload();
		} else if (command.equals("M.saveOld")) {
			handler.saveOld();
		} else if (command.equals("M.close")) {
			handler.close();
		}

	}

}
